import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { MapPin, Plane, Hotel } from 'lucide-react';

interface Package {
  _id: string;
  title: string;
  destination: string;
  price: number;
  image: string;
}

export default function Home() {
  const [featuredPackages, setFeaturedPackages] = useState<Package[]>([]);
  const [isLoggedIn, setIsLoggedIn] = useState(!!localStorage.getItem('token'));

  useEffect(() => {
    const fetchFeaturedPackages = async () => {
      try {
        const response = await fetch('http://localhost:5000/api/packages/featured');
        const data = await response.json();
        setFeaturedPackages(data.slice(0, 3));
      } catch (error) {
        console.error('Error fetching packages:', error);
        setFeaturedPackages([
          { _id: '1', title: 'Beach Getaway', destination: 'Maldives', price: 1200, image: 'https://via.placeholder.com/300x200' },
          { _id: '2', title: 'Mountain Retreat', destination: 'Himalayas', price: 800, image: 'https://via.placeholder.com/300x200' },
          { _id: '3', title: 'City Adventure', destination: 'New York', price: 1500, image: 'https://via.placeholder.com/300x200' },
        ]);
      }
    };
    fetchFeaturedPackages();
  }, []);

  return (
    <div>
      {/* Hero Section */}
      <div className="relative">
        <img
          className="w-full h-[500px] object-cover"
          src="https://images.unsplash.com/photo-1501785888041-af3ef285b470?ixlib=rb-4.0.3&auto=format&fit=crop&w=1740&q=80"
          alt="Travel destination"
        />
        <div className="absolute inset-0 bg-blue-700 mix-blend-multiply" />
        <div className="absolute inset-0 flex flex-col items-center justify-center text-center px-4">
          <motion.h1
            className="text-5xl font-extrabold text-white sm:text-6xl"
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1 }}
          >
            Explore the World with Travel Explorer
          </motion.h1>
          <motion.p
            className="mt-6 text-xl text-blue-100 max-w-2xl"
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.5 }}
          >
            Discover amazing travel packages and book your next adventure today!
          </motion.p>
          {!isLoggedIn && (
            <motion.div className="mt-8" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1 }}>
              <Link to="/signup" className="px-6 py-3 bg-white text-blue-600 rounded-md hover:bg-blue-100">
                Get Started
              </Link>
            </motion.div>
          )}
        </div>
      </div>

      {/* Featured Packages */}
      <motion.section
        className="mt-16"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <h2 className="text-3xl font-bold text-gray-900 text-center mb-8">Featured Packages</h2>
        <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {featuredPackages.map((pkg) => (
            <motion.div
              key={pkg._id}
              className="bg-white rounded-lg shadow-md overflow-hidden"
              whileHover={{ scale: 1.05 }}
            >
              <img src={pkg.image} alt={pkg.title} className="w-full h-48 object-cover" />
              <div className="p-4">
                <h3 className="text-lg font-semibold">{pkg.title}</h3>
                <p className="text-gray-600 flex items-center">
                  <MapPin className="h-4 w-4 mr-1" /> {pkg.destination}
                </p>
                <p className="text-blue-600 font-bold mt-2">${pkg.price}</p>
                <Link to={`/book-package/${pkg._id}`} className="mt-4 inline-block px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
                  Book Now
                </Link>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.section>
    </div>
  );
}