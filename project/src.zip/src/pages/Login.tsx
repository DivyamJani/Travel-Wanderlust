import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Mail, Lock, Eye, EyeOff } from 'lucide-react';
import axios from 'axios';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('');
  const [error, setError] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const navigate = useNavigate();

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!role) {
      setError('Please select a role');
      return;
    }
    try {
      const response = await axios.post('http://localhost:5000/api/login', { 
        email, 
        password, 
        role 
      });
      localStorage.setItem('token', response.data.token);
      localStorage.setItem('role', role);
      navigate('/');
    } catch (error) {
      setError('Invalid credentials');
    }
  };

  return (
    <motion.div 
      className="min-h-screen pt-16 pb-12 flex flex-col items-center justify-center bg-gray-100"
      initial={{ opacity: 0 }} 
      animate={{ opacity: 1 }}
    >
      <div className="w-full max-w-md px-4">
        {/* Card */}
        <div className="w-full shadow-lg border border-gray-200 overflow-hidden bg-white/80 rounded-lg">
          {/* CardHeader */}
          <div className="space-y-1 text-center p-6 border-b border-gray-200">
            {/* CardTitle */}
            <h2 className="text-2xl font-bold">Sign In</h2>
            {/* CardDescription */}
            <p className="text-sm text-gray-600">
              Enter your credentials to access your account
            </p>
          </div>
          
          {/* CardContent */}
          <div className="p-6">
            <form onSubmit={handleLogin} className="space-y-4">
              {error && <p className="text-red-500 text-center text-sm">{error}</p>}
              
              <div className="space-y-2">
                <label htmlFor="email" className="text-sm font-medium text-gray-700">Email</label>
                <div className="relative">
                  <input
                    id="email"
                    type="email"
                    placeholder="you@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    required
                  />
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                </div>
              </div>
              
              <div className="space-y-2">
                <label htmlFor="password" className="text-sm font-medium text-gray-700">Password</label>
                <div className="relative">
                  <input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full pl-10 pr-10 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    required
                  />
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                  <button
                    type="button"
                    onClick={togglePasswordVisibility}
                    className="absolute right-0 top-0 h-full px-3 text-gray-400 hover:text-gray-600 focus:outline-none"
                  >
                    {showPassword ? 
                      <EyeOff className="h-4 w-4" /> : 
                      <Eye className="h-4 w-4" />
                    }
                    <span className="sr-only">
                      {showPassword ? "Hide password" : "Show password"}
                    </span>
                  </button>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-700">Role</label>
                <div className="flex justify-between">
                  {['admin', 'hotelOwner', 'user'].map((r) => (
                    <label key={r} className="flex items-center text-sm text-gray-700">
                      <input
                        type="radio"
                        name="role"
                        value={r}
                        onChange={(e) => setRole(e.target.value)}
                        className="mr-2 h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300"
                      />
                      {r.charAt(0).toUpperCase() + r.slice(1)}
                    </label>
                  ))}
                </div>
              </div>

              <button 
                type="submit"
                className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-md transition-colors duration-200"
              >
                Sign In
              </button>
            </form>
          </div>
        </div>
      </div>
    </motion.div>
  );
}