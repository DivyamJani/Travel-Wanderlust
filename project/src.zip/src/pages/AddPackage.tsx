import { useState, FormEvent } from 'react';
import { motion } from 'framer-motion';
import axios from 'axios';

interface Package {
  title: string;
  destination: string;
  price: number;
  duration: string;
  description: string;
  image: string;
}

export default function AddPackage() {
  const [packageData, setPackageData] = useState<Package>({
    title: '',
    destination: '',
    price: 0,
    duration: '',
    description: '',
    image: '',
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setPackageData((prev) => ({ ...prev, [name]: name === 'price' ? Number(value) : value }));
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:5000/api/packages', packageData, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
      });
      alert('Package added successfully!');
      setPackageData({ title: '', destination: '', price: 0, duration: '', description: '', image: '' });
    } catch (error) {
      console.error('Error adding package:', error);
      alert('Failed to add package');
    }
  };

  return (
    <motion.div
      className="bg-white p-8 rounded-lg shadow-lg max-w-2xl mx-auto"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
    >
      <h1 className="text-3xl font-bold text-gray-900 mb-6">Add New Travel Package</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <input
          type="text"
          name="title"
          value={packageData.title}
          onChange={handleChange}
          placeholder="Package Title"
          className="w-full p-3 border rounded-lg"
          required
        />
        <input
          type="text"
          name="destination"
          value={packageData.destination}
          onChange={handleChange}
          placeholder="Destination"
          className="w-full p-3 border rounded-lg"
          required
        />
        <input
          type="number"
          name="price"
          value={packageData.price}
          onChange={handleChange}
          placeholder="Price ($)"
          className="w-full p-3 border rounded-lg"
          required
        />
        <input
          type="text"
          name="duration"
          value={packageData.duration}
          onChange={handleChange}
          placeholder="Duration (e.g., 5D/4N)"
          className="w-full p-3 border rounded-lg"
          required
        />
        <textarea
          name="description"
          value={packageData.description}
          onChange={handleChange}
          placeholder="Description"
          className="w-full p-3 border rounded-lg h-32"
          required
        />
        <input
          type="url"
          name="image"
          value={packageData.image}
          onChange={handleChange}
          placeholder="Image URL"
          className="w-full p-3 border rounded-lg"
          required
        />
        <button type="submit" className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700">
          Add Package
        </button>
      </form>
    </motion.div>
  );
}