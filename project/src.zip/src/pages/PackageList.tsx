import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Search, MapPin } from 'lucide-react';

interface Package {
  _id: string;
  title: string;
  destination: string;
  price: number;
  duration: string;
  image: string;
}

export default function PackageList() {
  const [packages, setPackages] = useState<Package[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterPrice, setFilterPrice] = useState('all');

  useEffect(() => {
    const fetchPackages = async () => {
      try {
        const response = await fetch('http://localhost:5000/api/packages');
        const data = await response.json();
        setPackages(data);
      } catch (error) {
        console.error('Error fetching packages:', error);
        setPackages([
          { _id: '1', title: 'Beach Getaway', destination: 'Maldives', price: 1200, duration: '5D/4N', image: 'https://via.placeholder.com/300x200' },
          { _id: '2', title: 'Mountain Retreat', destination: 'Himalayas', price: 800, duration: '4D/3N', image: 'https://via.placeholder.com/300x200' },
        ]);
      }
    };
    fetchPackages();
  }, []);

  const filteredPackages = packages.filter((pkg) => {
    const matchesSearch = pkg.title.toLowerCase().includes(searchTerm.toLowerCase()) || pkg.destination.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesPrice = filterPrice === 'all' || (filterPrice === 'low' ? pkg.price < 1000 : pkg.price >= 1000);
    return matchesSearch && matchesPrice;
  });

  return (
    <div>
      <h1 className="text-3xl font-bold text-gray-900 mb-8">Travel Packages</h1>
      <div className="flex flex-col sm:flex-row gap-4 mb-8">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            placeholder="Search by title or destination..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border rounded-lg"
          />
        </div>
        <select
          value={filterPrice}
          onChange={(e) => setFilterPrice(e.target.value)}
          className="px-4 py-2 border rounded-lg"
        >
          <option value="all">All Prices</option>
          <option value="low">Below $1000</option>
          <option value="high">Above $1000</option>
        </select>
      </div>

      <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
        {filteredPackages.map((pkg) => (
          <motion.div
            key={pkg._id}
            className="bg-white rounded-lg shadow-md overflow-hidden"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            whileHover={{ scale: 1.05 }}
          >
            <img src={pkg.image} alt={pkg.title} className="w-full h-48 object-cover" />
            <div className="p-4">
              <h3 className="text-lg font-semibold">{pkg.title}</h3>
              <p className="text-gray-600 flex items-center">
                <MapPin className="h-4 w-4 mr-1" /> {pkg.destination}
              </p>
              <p className="text-gray-600">{pkg.duration}</p>
              <p className="text-blue-600 font-bold mt-2">${pkg.price}</p>
              <Link to={`/book-package/${pkg._id}`} className="mt-4 inline-block px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
                Book Now
              </Link>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}