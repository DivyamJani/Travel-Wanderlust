import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';

// Define interfaces for the data structure
interface User {
  _id: string;
  name: string;
  email: string;
}

interface Package {
  _id: string;
  title: string;
  price: number;
}

interface Booking {
  _id: string;
  userId: User;
  packageId: Package;
  travelDate: string;
}

export default function HotelBookings() {
  const [bookings, setBookings] = useState<Booking[]>([]);

  useEffect(() => {
    const fetchBookings = async () => {
      try {
        const response = await fetch('http://localhost:5000/api/bookings/hotel-bookings', {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
        });
        if (!response.ok) {
          throw new Error('Failed to fetch bookings');
        }
        const data: Booking[] = await response.json();
        setBookings(data);
      } catch (error) {
        console.error('Error fetching hotel bookings:', error);
      }
    };
    fetchBookings();
  }, []);

  return (
    <motion.div className="space-y-8" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
      <h1 className="text-3xl font-bold text-gray-900">Hotel Bookings</h1>
      <div className="bg-white shadow-md rounded-lg overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">User</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Package</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Travel Date</th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Price</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {bookings.map((booking) => (
              <tr key={booking._id}>
                <td className="px-6 py-4 whitespace-nowrap">{booking.userId.name} ({booking.userId.email})</td>
                <td className="px-6 py-4 whitespace-nowrap">{booking.packageId.title}</td>
                <td className="px-6 py-4 whitespace-nowrap">{new Date(booking.travelDate).toLocaleDateString()}</td>
                <td className="px-6 py-4 whitespace-nowrap">${booking.packageId.price}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </motion.div>
  );
}