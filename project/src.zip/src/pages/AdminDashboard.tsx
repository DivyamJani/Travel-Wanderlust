import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Users, Package, DollarSign } from 'lucide-react';

interface DashboardData {
  totalUsers: number;
  totalHotelOwners: number;
  totalPackages: number;
  totalBookings: number;
}

export default function AdminDashboard() {
  const [data, setData] = useState<DashboardData>({
    totalUsers: 0,
    totalHotelOwners: 0,
    totalPackages: 0,
    totalBookings: 0,
  });

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch('http://localhost:5000/api/admin/dashboard', {
          headers: { Authorization: `Bearer ${localStorage.getItem('token')}` },
        });
        const result = await response.json();
        setData(result);
      } catch (error) {
        console.error('Error fetching dashboard data:', error);
        setData({ totalUsers: 500, totalHotelOwners: 50, totalPackages: 200, totalBookings: 300 });
      }
    };
    fetchData();
  }, []);

  return (
    <motion.div className="space-y-8" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
      <h1 className="text-3xl font-bold text-gray-900">Admin Dashboard</h1>
      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
        <div className="bg-white p-6 rounded-lg shadow-md flex items-center">
          <Users className="h-8 w-8 text-blue-600 mr-4" />
          <div>
            <p className="text-2xl font-bold">{data.totalUsers}</p>
            <p className="text-gray-600">Total Users</p>
          </div>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-md flex items-center">
          <Users className="h-8 w-8 text-blue-600 mr-4" />
          <div>
            <p className="text-2xl font-bold">{data.totalHotelOwners}</p>
            <p className="text-gray-600">Hotel Owners</p>
          </div>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-md flex items-center">
          <Package className="h-8 w-8 text-blue-600 mr-4" />
          <div>
            <p className="text-2xl font-bold">{data.totalPackages}</p>
            <p className="text-gray-600">Total Packages</p>
          </div>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-md flex items-center">
          <DollarSign className="h-8 w-8 text-blue-600 mr-4" />
          <div>
            <p className="text-2xl font-bold">{data.totalBookings}</p>
            <p className="text-gray-600">Total Bookings</p>
          </div>
        </div>
      </div>
    </motion.div>
  );
}