import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { User, Mail, Lock, Eye, EyeOff } from 'lucide-react';
import axios from 'axios';

export default function Signup() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    role: '',
    hotelName: '',
    hotelLocation: '',
  });
  const [error, setError] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const navigate = useNavigate();

  const handleChange = (e: { target: { name: any; value: any; }; }) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  const handleSubmit = async (e: { preventDefault: () => void; }) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:5000/api/signup', formData);
      console.log('Signup success:', response.data);
      navigate('/verify-otp', { state: { email: formData.email } });
    } catch (error) {
      if (axios.isAxiosError(error) && error.response) {
        console.error('Signup error:', error.response.data);
        setError(error.response.data.message || 'Signup failed');
      } else {
        console.error('Signup error:', error);
        setError('An unexpected error occurred');
      }
    }
  };

  return (
    <motion.div 
      className="min-h-screen pt-16 pb-12 flex flex-col items-center justify-center bg-gray-100"
      initial={{ opacity: 0 }} 
      animate={{ opacity: 1 }}
    >
      <div className="w-full max-w-md px-4">
        {/* Card */}
        <div className="w-full shadow-lg border border-gray-200 overflow-hidden bg-white/80 rounded-lg">
          {/* CardHeader */}
          <div className="space-y-1 text-center p-6 border-b border-gray-200">
            {/* CardTitle */}
            <h2 className="text-2xl font-bold">Create Account</h2>
            {/* CardDescription */}
            <p className="text-sm text-gray-600">
              Enter your information to create an account
            </p>
          </div>
          
          {/* CardContent */}
          <div className="p-6">
            <form onSubmit={handleSubmit} className="space-y-4">
              {error && <p className="text-red-500 text-center text-sm">{error}</p>}
              
              <div className="space-y-2">
                <label htmlFor="name" className="text-sm font-medium text-gray-700">Full Name</label>
                <div className="relative">
                  <input
                    id="name"
                    type="text"
                    name="name"
                    placeholder="John Doe"
                    value={formData.name}
                    onChange={handleChange}
                    className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    required
                  />
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                </div>
              </div>

              <div className="space-y-2">
                <label htmlFor="email" className="text-sm font-medium text-gray-700">Email</label>
                <div className="relative">
                  <input
                    id="email"
                    type="email"
                    name="email"
                    placeholder="you@example.com"
                    value={formData.email}
                    onChange={handleChange}
                    className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    required
                  />
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                </div>
              </div>
              
              <div className="space-y-2">
                <label htmlFor="password" className="text-sm font-medium text-gray-700">Password</label>
                <div className="relative">
                  <input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    name="password"
                    placeholder="••••••••"
                    value={formData.password}
                    onChange={handleChange}
                    className="w-full pl-10 pr-10 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    required
                  />
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                  <button
                    type="button"
                    onClick={togglePasswordVisibility}
                    className="absolute right-0 top-0 h-full px-3 text-gray-400 hover:text-gray-600 focus:outline-none"
                  >
                    {showPassword ? 
                      <EyeOff className="h-4 w-4" /> : 
                      <Eye className="h-4 w-4" />
                    }
                    <span className="sr-only">
                      {showPassword ? "Hide password" : "Show password"}
                    </span>
                  </button>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-700">Role</label>
                <div className="flex justify-between">
                  {['admin', 'hotelOwner', 'user'].map((r) => (
                    <label key={r} className="flex items-center text-sm text-gray-700">
                      <input
                        type="radio"
                        name="role"
                        value={r}
                        onChange={handleChange}
                        className="mr-2 h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300"
                      />
                      {r.charAt(0).toUpperCase() + r.slice(1)}
                    </label>
                  ))}
                </div>
              </div>

              {formData.role === 'hotelOwner' && (
                <>
                  <div className="space-y-2">
                    <label htmlFor="hotelName" className="text-sm font-medium text-gray-700">Hotel Name</label>
                    <input
                      id="hotelName"
                      type="text"
                      name="hotelName"
                      placeholder="Hotel Name"
                      value={formData.hotelName}
                      onChange={handleChange}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="hotelLocation" className="text-sm font-medium text-gray-700">Hotel Location</label>
                    <input
                      id="hotelLocation"
                      type="text"
                      name="hotelLocation"
                      placeholder="Hotel Location"
                      value={formData.hotelLocation}
                      onChange={handleChange}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      required
                    />
                  </div>
                </>
              )}

              <div className="text-xs text-gray-500">
                By creating an account, you agree to our{' '}
                <Link to="#" className="text-blue-600 hover:underline">
                  Terms of Service
                </Link>{' '}
                and{' '}
                <Link to="#" className="text-blue-600 hover:underline">
                  Privacy Policy
                </Link>
              </div>

              <button 
                type="submit"
                className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-md transition-colors duration-200"
              >
                Create Account
              </button>
            </form>
          </div>

          {/* CardFooter */}
          <div className="p-6 border-t border-gray-200 flex justify-center">
            <div className="text-center text-sm">
              Already have an account?{' '}
              <Link 
                to="/login" 
                className="text-blue-600 font-medium hover:underline"
              >
                Sign in
              </Link>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}