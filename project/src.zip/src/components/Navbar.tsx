import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { MapPin, Menu, X } from 'lucide-react';

export default function Navbar() {
  const [isOpen, setIsOpen] = React.useState(false);
  const role = localStorage.getItem('role') || '';
  const token = localStorage.getItem('token');
  const navigate = useNavigate();

  const navItems = {
    common: [
      { path: '/', label: 'Home' },
    ],
    user: [
      { path: '/packages', label: 'Packages' },
      { path: '/my-bookings', label: 'My Bookings' }, // Add user bookings link
    ],
    hotelOwner: [
      { path: '/add-package', label: 'Add Package' },
      { path: '/hotel-bookings', label: 'Hotel Bookings' }, // Add hotel bookings link
    ],
    admin: [
      { path: '/admin-dashboard', label: 'Dashboard' },
      { path: '/all-bookings', label: 'All Bookings' }, // Add all bookings link
    ],
  };

  const items = [
    ...navItems.common,
    ...(role === 'user' ? navItems.user : []),
    ...(role === 'hotelOwner' ? navItems.hotelOwner : []),
    ...(role === 'admin' ? navItems.admin : []),
  ];

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('role');
    localStorage.removeItem('email');
    setIsOpen(false);
    navigate('/login');
  };

  return (
    <nav className="bg-blue-600">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <NavLink to="/" className="flex items-center">
            <MapPin className="h-8 w-8 text-white" />
            <span className="ml-2 text-white font-bold text-lg">Travel Explorer</span>
          </NavLink>

          {/* Desktop Navigation */}
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-4">
              {items.map((item) => (
                <NavLink
                  key={item.path}
                  to={item.path}
                  className={({ isActive }) =>
                    `px-3 py-2 rounded-md text-sm font-medium ${
                      isActive ? 'bg-blue-700 text-white' : 'text-blue-100 hover:bg-blue-500'
                    }`
                  }
                >
                  {item.label}
                </NavLink>
              ))}
              {token ? (
                <button
                  onClick={handleLogout}
                  className="px-3 py-2 rounded-md text-sm font-medium text-blue-100 hover:bg-blue-500"
                >
                  Logout
                </button>
              ) : (
                <>
                  <NavLink
                    to="/login"
                    className={({ isActive }) =>
                      `px-3 py-2 rounded-md text-sm font-medium ${
                        isActive ? 'bg-blue-700 text-white' : 'text-blue-100 hover:bg-blue-500'
                      }`
                    }
                  >
                    Login
                  </NavLink>
                  <NavLink
                    to="/signup"
                    className={({ isActive }) =>
                      `px-3 py-2 rounded-md text-sm font-medium ${
                        isActive ? 'bg-blue-700 text-white' : 'text-blue-100 hover:bg-blue-500'
                      }`
                    }
                  >
                    Signup
                  </NavLink>
                </>
              )}
            </div>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="inline-flex items-center justify-center p-2 rounded-md text-blue-100 hover:bg-blue-500"
            >
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation */}
      {isOpen && (
        <div className="md:hidden">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            {items.map((item) => (
              <NavLink
                key={item.path}
                to={item.path}
                className={({ isActive }) =>
                  `block px-3 py-2 rounded-md text-base font-medium ${
                    isActive ? 'bg-blue-700 text-white' : 'text-blue-100 hover:bg-blue-500'
                  }`
                }
                onClick={() => setIsOpen(false)}
              >
                {item.label}
              </NavLink>
            ))}
            {token ? (
              <button
                onClick={handleLogout}
                className="block w-full text-left px-3 py-2 rounded-md text-base font-medium text-blue-100 hover:bg-blue-500"
              >
                Logout
              </button>
            ) : (
              <>
                <NavLink
                  to="/login"
                  className={({ isActive }) =>
                    `block px-3 py-2 rounded-md text-base font-medium ${
                      isActive ? 'bg-blue-700 text-white' : 'text-blue-100 hover:bg-blue-500'
                    }`
                  }
                  onClick={() => setIsOpen(false)}
                >
                  Login
                </NavLink>
                <NavLink
                  to="/signup"
                  className={({ isActive }) =>
                    `block px-3 py-2 rounded-md text-base font-medium ${
                      isActive ? 'bg-blue-700 text-white' : 'text-blue-100 hover:bg-blue-500'
                    }`
                  }
                  onClick={() => setIsOpen(false)}
                >
                  Signup
                </NavLink>
              </>
            )}
          </div>
        </div>
      )}
    </nav>
  );
}